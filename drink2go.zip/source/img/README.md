Папка для изображений.

Все SVG-иконки предназначенных для спрайта кладите в `img/icons/`:
```
img/
  icons/
    vk.svg
```

Остальную векторную и растровую графику кладите непосредственно в папку `img/`:
```
img/
  bg.jpg
  hero.png
  burger.svg
```

Графику можно группировать папками в `img/`:
```
img/
  catalog/
    product-1.jpg
    product-2.jpg
  form/
    check.jpg
    uncheck.jpg
  bg.jpg
  hero.png
  burger.svg
```
