/* в этот файл добавляет скрипты*/
import {detectedScript, toggleClickHandler} from "./modules/menu.js";
import {arrowClickHandler} from "./modules/slider.js";

detectedScript();
toggleClickHandler();
arrowClickHandler();
